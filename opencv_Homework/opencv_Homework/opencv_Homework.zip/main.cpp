#include <opencv2/opencv.hpp>
using namespace cv;

void first();
void second();
void third();


int main() {
	first();
	//second();
	//third();
}